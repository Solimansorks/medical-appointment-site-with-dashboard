<nav class="bg-white dark:bg-gray-800 shadow mb-4 p-4 flex justify-between items-center">
    <div>
        <a href="/" class="font-bold text-lg text-blue-600 dark:text-blue-300">Medical System</a>
    </div>
    <div class="flex items-center space-x-4">
        <?php if(auth()->guard()->check()): ?>
            <span class="text-sm text-gray-700 dark:text-gray-200">
                <?php echo e(auth()->user()->name); ?> (<?php echo e(auth()->user()->role); ?>)
            </span>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button class="text-red-600 hover:underline text-sm">Logout</button>
            </form>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="text-sm text-blue-500 hover:underline">Login</a>
        <?php endif; ?>
    </div>
</nav>
<?php /**PATH G:\شغل بورتفوليو\medical-appointment\medical-appointment\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>