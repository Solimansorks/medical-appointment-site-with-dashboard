<x-app-layout>
    <h2>My Appointments</h2>

    @if($appointments->count())
        <table>
            <thead>
                <tr>
                    <th>Doctor</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach($appointments as $appointment)
                    <tr>
                        <td>{{ $appointment->doctor->name }}</td>
                        <td>{{ $appointment->appointment_date }}</td>
                        <td>{{ $appointment->appointment_time }}</td>
                        <td>{{ ucfirst($appointment->status) }}</td>
                        <td class="p-2 border">
    @if($appointment->prescription)
        <a href="{{ route('prescriptions.show', $appointment->id) }}" class="text-blue-600 hover:underline">
            View Prescription
        </a>
    @else
        <span class="text-gray-400">N/A</span>
    @endif
</td>

                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <p>No appointments found.</p>
    @endif
</x-app-layout>
