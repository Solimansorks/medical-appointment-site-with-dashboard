<?php

namespace App\Http\Controllers;

use App\Models\Schedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ScheduleController extends Controller
{
    /**
     * عرض كل الجداول الخاصة بالدكتور
     */
    public function index()
    {
        $schedules = Schedule::where('doctor_id', auth()->id())->get();
        return view('schedules.index', compact('schedules'));
    }

    /**
     * حفظ جدول جديد
     */
    public function store(Request $request)
    {
        $request->validate([
            'day_of_week' => 'required|in:Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
        ]);

        Schedule::create([
            'doctor_id' => auth()->id(),
            'day_of_week' => $request->day_of_week,
            'start_time' => $request->start_time,
            'end_time' => $request->end_time,
        ]);

        return redirect()->route('schedules.index')->with('success', 'Schedule saved successfully.');
    }

    /**
     * عرض نموذج تعديل الجدول
     */
    public function edit(Schedule $schedule)
    {
        $this->authorizeSchedule($schedule);
        return view('schedules.edit', compact('schedule'));
    }

    /**
     * تحديث الجدول
     */
    public function update(Request $request, Schedule $schedule)
    {
        $this->authorizeSchedule($schedule);

        $request->validate([
            'day_of_week' => 'required|string|in:Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
        ]);

        $schedule->update($request->only(['day_of_week', 'start_time', 'end_time']));

        return redirect()->route('schedules.index')->with('success', 'Schedule updated.');
    }

    /**
     * حذف الجدول
     */
    public function destroy(Schedule $schedule)
    {
        $this->authorizeSchedule($schedule);
        $schedule->delete();

        return redirect()->route('schedules.index')->with('success', 'Schedule deleted.');
    }

    /**
     * تأمين العمليات بناءً على صلاحية الدكتور
     */
    protected function authorizeSchedule(Schedule $schedule)
    {
        if ($schedule->doctor_id !== Auth::id()) {
            abort(403);
        }
    }
}
