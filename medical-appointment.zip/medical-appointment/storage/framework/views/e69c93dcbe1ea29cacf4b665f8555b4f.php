<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h2 class="text-xl font-bold mb-4">My Appointments</h2>

    
    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <table class="w-full table-auto border">
        <thead class="bg-gray-100">
            <tr>
                <th class="p-2 border">#</th>
                <?php if(auth()->user()->role === 'doctor'): ?>
                    <th class="p-2 border">Patient</th>
                <?php else: ?>
                    <th class="p-2 border">Doctor</th>
                <?php endif; ?>
                <th class="p-2 border">Date</th>
                <th class="p-2 border">Time</th>
                <th class="p-2 border">Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $statusColors = [
                    'pending' => 'bg-yellow-200 text-yellow-800',
                    'confirmed' => 'bg-green-200 text-green-800',
                    'cancelled' => 'bg-red-200 text-red-800',
                ];
            ?>

            <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border">
                    <td class="p-2 border"><?php echo e($loop->iteration); ?></td>

                    
                    <td class="p-2 border">
                        <?php echo e(auth()->user()->role === 'doctor'
                            ? $appointment->patient->name ?? '-' 
                            : $appointment->doctor->name ?? '-'); ?>

                    </td>

                    <td class="p-2 border"><?php echo e($appointment->appointment_date); ?></td>
                    <td class="p-2 border"><?php echo e($appointment->appointment_time); ?></td>
                    
                    <td class="p-2 border">
                        <span class="px-2 py-1 rounded <?php echo e($statusColors[$appointment->status] ?? 'bg-gray-200'); ?>">
                            <?php echo e(ucfirst($appointment->status)); ?>

                        </span>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center p-4 text-gray-600">
                        No appointments found.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Paragon\Desktop\medical-appointment\resources\views/appointments/index.blade.php ENDPATH**/ ?>