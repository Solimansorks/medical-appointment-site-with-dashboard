<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
            Doctor Dashboard
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="p-6 bg-white shadow-md rounded-lg">
        
        <h3 class="text-lg font-semibold text-gray-700 mb-1">
            Welcome, Dr. <?php echo e(Auth::user()->name); ?> 👋
        </h3>
        <p class="text-gray-600 mb-5">
            Here is a quick overview of your appointments.
        </p>

        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div class="bg-blue-50 border border-blue-200 p-4 rounded-lg shadow-sm">
                <h4 class="text-sm font-medium text-blue-700">Total Appointments</h4>
                <p class="text-3xl font-bold text-blue-900 mt-1">
                    <?php echo e(\App\Models\Appointment::where('doctor_id', Auth::id())->count()); ?>

                </p>
            </div>

            
            <div class="bg-green-50 border border-green-200 p-4 rounded-lg shadow-sm">
                <h4 class="text-sm font-medium text-green-700">Confirmed</h4>
                <p class="text-3xl font-bold text-green-900 mt-1">
                    <?php echo e(\App\Models\Appointment::where('doctor_id', Auth::id())->where('status', 'confirmed')->count()); ?>

                </p>
            </div>

            
            <div class="bg-yellow-50 border border-yellow-200 p-4 rounded-lg shadow-sm">
                <h4 class="text-sm font-medium text-yellow-700">Pending</h4>
                <p class="text-3xl font-bold text-yellow-900 mt-1">
                    <?php echo e(\App\Models\Appointment::where('doctor_id', Auth::id())->where('status', 'pending')->count()); ?>

                </p>
            </div>
        </div>

        
        <div class="mt-6 text-right">
            <a href="<?php echo e(route('doctor.appointments')); ?>"
               class="inline-block bg-blue-600 text-black px-4 py-2 rounded hover:bg-blue-700 transition">
                View All Appointments →
            </a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\شغل بورتفوليو\medical-appointment\medical-appointment\resources\views/doctor/dashboard.blade.php ENDPATH**/ ?>