<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class AppointmentStatusChanged extends Notification
{
    use Queueable;

    public $appointment;
    public $newStatus;

    public function __construct($appointment, $newStatus)
    {
        $this->appointment = $appointment;
        $this->newStatus = $newStatus;
    }

    public function via($notifiable)
    {
        return ['database'];
    }

    public function toArray($notifiable)
    {
        return [
            'message' => 'Your appointment on ' . $this->appointment->appointment_date . ' at ' . $this->appointment->appointment_time .
                ' has been ' . strtoupper($this->newStatus) . ' by Dr. ' . $this->appointment->doctor->name,
        ];
    }
}
