<x-app-layout>
    <h2 class="text-xl font-bold mb-4">
        Write Prescription for {{ $appointment->patient->name }}
    </h2>

    {{-- رسالة نجاح --}}
    @if(session('success'))
        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    {{-- عرض الأخطاء --}}
    @if($errors->any())
        <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
            @foreach($errors->all() as $error)
                <div>• {{ $error }}</div>
            @endforeach
        </div>
    @endif

    {{-- النموذج --}}
    <form method="POST" action="{{ route('prescriptions.store', $appointment->id) }}">
        @csrf

        <textarea name="content" rows="10" class="w-full border p-2 rounded" required placeholder="Type prescription here...">
            {{ old('content', $appointment->prescription->content ?? '') }}
        </textarea>

        <button type="submit" class="mt-3 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded">
            Save Prescription
        </button>
    </form>
</x-app-layout>
