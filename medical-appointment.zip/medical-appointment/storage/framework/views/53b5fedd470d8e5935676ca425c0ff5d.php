<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-bold">My Patient Appointments</h2>
     <?php $__env->endSlot(); ?>

    <div class="p-4">

        
        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 p-3 rounded mb-4 shadow">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($appointments->count()): ?>
            <table class="w-full table-auto border rounded shadow">
                <thead class="bg-gray-100 text-left">
                    <tr>
                        <th class="p-3 border">Patient</th>
                        <th class="p-3 border">Date</th>
                        <th class="p-3 border">Time</th>
                        <th class="p-3 border">Status</th>
                        <th class="p-3 border">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50">
                            <td class="p-3 border"><?php echo e($appointment->patient->name); ?></td>
                            <td class="p-3 border"><?php echo e($appointment->appointment_date); ?></td>
                            <td class="p-3 border"><?php echo e($appointment->appointment_time); ?></td>
                            <td class="p-3 border">
                                <span class="px-2 py-1 text-sm font-semibold rounded 
                                    <?php echo e($appointment->status == 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                        ($appointment->status == 'confirmed' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800')); ?>">
                                    <?php echo e(ucfirst($appointment->status)); ?>

                                </span>
                            </td>
                            <td class="p-3 border">
                                <?php if($appointment->status == 'pending'): ?>
                                    <div class="flex space-x-2">
                                        
                                        <form method="POST" action="<?php echo e(route('doctor.appointments.updateStatus', $appointment->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="status" value="confirmed">
                                            <button type="submit" class="text-green-600 hover:underline" onclick="return confirm('Are you sure to confirm this appointment?')">
                                                ✅ Confirm
                                            </button>
                                        </form>

                                        
                                        <form method="POST" action="<?php echo e(route('doctor.appointments.updateStatus', $appointment->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="status" value="cancelled">
                                            <button type="submit" class="text-red-600 hover:underline"
                                                onclick="return confirm('Are you sure to cancel this appointment?')">
                                                ❌ Cancel
                                            </button>
                                        </form>
                                    </div>
                                <?php else: ?>
                                    <span class="text-gray-400 italic">No actions</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="text-gray-600 text-center mt-8">
                No appointments yet.
            </div>
        <?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Paragon\Desktop\medical-appointment\resources\views/doctor/appointments.blade.php ENDPATH**/ ?>