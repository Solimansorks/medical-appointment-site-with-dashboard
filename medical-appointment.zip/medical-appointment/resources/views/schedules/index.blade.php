<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold">🗓️ My Weekly Schedule</h2>
    </x-slot>

    <div class="p-4 max-w-3xl mx-auto">
        @if (session('success'))
            <div class="bg-green-100 text-green-800 p-3 rounded mb-4">
                {{ session('success') }}
            </div>
        @endif

        <!-- Form لإضافة جدول جديد -->
        <form action="{{ route('schedules.store') }}" method="POST" class="bg-white p-4 rounded shadow mb-6">
            @csrf
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label>Day of Week</label>
                    <select name="day_of_week" class="w-full border rounded p-2" required>
                        @foreach(['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'] as $day)
                            <option value="{{ $day }}">{{ $day }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label>Start Time</label>
                    <input type="time" name="start_time" class="w-full border rounded p-2" required>
                </div>
                <div>
                    <label>End Time</label>
                    <input type="time" name="end_time" class="w-full border rounded p-2" required>
                </div>
            </div>
            <button type="submit" class="mt-4 bg-blue-600 text-white px-4 py-2 rounded">Save</button>
        </form>

        <!-- جدول عرض المواعيد -->
        <table class="w-full bg-white rounded shadow">
            <thead class="bg-gray-100">
                <tr>
                    <th class="p-2 text-left">Day</th>
                    <th class="p-2 text-left">Start Time</th>
                    <th class="p-2 text-left">End Time</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($schedules as $schedule)
                    <tr class="border-t">
                        <td class="p-2">{{ $schedule->day_of_week }}</td>
                        <td class="p-2">{{ \Carbon\Carbon::parse($schedule->start_time)->format('H:i') }}</td>
                        <td class="p-2">{{ \Carbon\Carbon::parse($schedule->end_time)->format('H:i') }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</x-app-layout>
