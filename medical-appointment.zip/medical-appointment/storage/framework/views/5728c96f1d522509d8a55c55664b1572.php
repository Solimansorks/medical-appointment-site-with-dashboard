<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            🧑‍⚕️ Patient Dashboard
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6 px-4 mx-auto max-w-7xl">
        <div class="mb-4">
            <h3 class="text-lg font-medium">Welcome, <?php echo e(Auth::user()->name); ?> 👋</h3>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-4 p-4 bg-green-100 text-green-700 rounded">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($appointments->isEmpty()): ?>
            <p class="text-gray-600">You have no appointments yet.</p>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full table-auto border-collapse bg-white shadow rounded">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="px-4 py-2 text-left">Date</th>
                            <th class="px-4 py-2 text-left">Time</th>
                            <th class="px-4 py-2 text-left">Doctor</th>
                            <th class="px-4 py-2 text-left">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b">
                                <td class="px-4 py-2"><?php echo e($appointment->appointment_date); ?></td>
                                <td class="px-4 py-2"><?php echo e($appointment->appointment_time); ?></td>
                                <td class="px-4 py-2"><?php echo e($appointment->doctor->name ?? 'N/A'); ?></td>
                                <td class="px-4 py-2">
                                    <?php
                                        $statusColor = match($appointment->status) {
                                            'pending' => 'text-yellow-500',
                                            'confirmed' => 'text-green-600',
                                            'cancelled' => 'text-red-500',
                                            default => 'text-gray-500',
                                        };
                                    ?>
                                    <span class="<?php echo e($statusColor); ?> font-semibold">
                                        <?php echo e(ucfirst($appointment->status)); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH G:\شغل بورتفوليو\medical-appointment\medical-appointment\resources\views/patient/dashboard.blade.php ENDPATH**/ ?>