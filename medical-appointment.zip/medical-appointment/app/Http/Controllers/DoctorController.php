<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Appointment;
use App\Models\Prescription;

class DoctorController extends Controller
{
    /**
     * عرض مواعيد الدكتور
     */
    public function appointments()
    {
        $appointments = Appointment::with('patient')
            ->where('doctor_id', Auth::id())
            ->orderBy('appointment_date', 'asc')
            ->orderBy('appointment_time', 'asc')
            ->get();

        return view('doctor.appointments', compact('appointments'));
    }

    /**
     * تحديث حالة الموعد
     */
    public function updateStatus(Request $request, Appointment $appointment)
    {
        $request->validate([
            'status' => 'required|in:confirmed,cancelled',
        ]);

        if ($appointment->doctor_id !== auth()->id()) {
            abort(403);
        }

        $appointment->status = $request->status;
        $appointment->save();

        return redirect()->back()->with('success', 'Appointment status updated successfully!');
    }

    /**
     * عرض نموذج وصفة طبية
     */
    public function createPrescription(Appointment $appointment)
    {
        if ($appointment->doctor_id !== auth()->id()) abort(403);

        return view('doctor.prescriptions.create', compact('appointment'));
    }

    /**
     * حفظ أو تحديث وصفة طبية
     */
    public function storePrescription(Request $request, Appointment $appointment)
    {
        $request->validate([
            'content' => 'required|string|min:10',
        ]);

        if ($appointment->doctor_id !== auth()->id()) abort(403);

        Prescription::updateOrCreate(
            ['appointment_id' => $appointment->id],
            ['content' => $request->content]
        );

        return redirect()->route('doctor.appointments')->with('success', 'Prescription saved successfully.');
    }

    /**
     * عرض لوحة تحكم الدكتور
     */
    public function dashboard()
    {
        $appointments = Appointment::where('doctor_id', Auth::id())->count();
        return view('doctor.dashboard', compact('appointments'));
    }
}
