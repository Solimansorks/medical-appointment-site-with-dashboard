<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Models\Appointment;
use App\Models\Prescription;

class PatientController extends Controller
{
    /**
     * لوحة تحكم المريض
     */
    public function dashboard()
    {
        $appointments = Appointment::with('doctor')
            ->where('patient_id', Auth::id())
            ->orderBy('appointment_date', 'desc')
            ->get();

        return view('patient.dashboard', compact('appointments'));
    }

    /**
     * عرض قائمة المواعيد
     */
    public function appointments()
    {
        $appointments = Appointment::where('patient_id', auth()->id())
            ->with('doctor')
            ->latest()
            ->get();

        return view('patient.appointments', compact('appointments'));
    }

    /**
     * عرض وصفة الموعد
     */
    public function showPrescription(Appointment $appointment)
    {
        if ($appointment->patient_id !== auth()->id()) {
            abort(403); // تأكد إن المريض هو صاحب الموعد
        }

        $prescription = $appointment->prescription;

        if (!$prescription) {
            return back()->with('error', 'No prescription found for this appointment.');
        }

        return view('patient.prescriptions.show', compact('prescription'));
    }
}
