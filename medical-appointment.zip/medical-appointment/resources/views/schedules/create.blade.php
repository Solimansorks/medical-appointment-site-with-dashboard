<x-app-layout>
    <h2 class="text-xl font-bold mb-4">Add New Schedule</h2>

    <form method="POST" action="{{ route('schedules.store') }}">
        @csrf

        <div class="mb-4">
            <label>Day of Week</label>
            <input type="text" name="day_of_week" class="input" required>
        </div>

        <div class="mb-4">
            <label>Start Time</label>
            <input type="time" name="start_time" class="input" required>
        </div>

        <div class="mb-4">
            <label>End Time</label>
            <input type="time" name="end_time" class="input" required>
        </div>

        <button type="submit" class="btn btn-success">Save</button>
    </form>
</x-app-layout>
