<x-app-layout>
    <h2 class="text-xl font-bold mb-4">Book Appointment</h2>

    @if($errors->any())
        <div class="bg-red-100 text-red-700 p-3 mb-4 rounded">
            @foreach($errors->all() as $error)
                <div>• {{ $error }}</div>
            @endforeach
        </div>
    @endif

    <form method="POST" action="{{ route('appointments.store') }}">
        @csrf

        <div class="mb-4">
            <label for="doctor_id" class="block font-medium mb-1">Choose Doctor</label>
            <select name="doctor_id" id="doctor_id" class="w-full border rounded p-2" required>
                <option value="">-- Select Doctor --</option>
                @foreach($doctors as $doctor)
                    <option value="{{ $doctor->id }}" {{ old('doctor_id') == $doctor->id ? 'selected' : '' }}>
                        {{ $doctor->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-4">
            <label for="appointment_date" class="block font-medium mb-1">Date</label>
            <input type="date" name="appointment_date" id="appointment_date"
                   class="w-full border rounded p-2"
                   value="{{ old('appointment_date') }}" required>
        </div>

        <div class="mb-4">
            <label for="appointment_time" class="block font-medium mb-1">Time</label>
            <input type="time" name="appointment_time" id="appointment_time"
                   class="w-full border rounded p-2"
                   value="{{ old('appointment_time') }}" required>
        </div>

        <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-black px-4 py-2 rounded">
            submit
        </button>
    </form>
</x-app-layout>
