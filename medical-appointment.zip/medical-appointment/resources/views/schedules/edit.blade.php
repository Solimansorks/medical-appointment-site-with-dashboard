<x-app-layout>
    <h2 class="text-xl font-bold mb-4">Edit Schedule</h2>

    <form method="POST" action="{{ route('schedules.update', $schedule->id) }}">
        @csrf
        @method('PUT')

        <div class="mb-4">
            <label>Day of Week</label>
            <input type="text" name="day_of_week" class="input" value="{{ $schedule->day_of_week }}" required>
        </div>

        <div class="mb-4">
            <label>Start Time</label>
            <input type="time" name="start_time" class="input" value="{{ $schedule->start_time }}" required>
        </div>

        <div class="mb-4">
            <label>End Time</label>
            <input type="time" name="end_time" class="input" value="{{ $schedule->end_time }}" required>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</x-app-layout>
