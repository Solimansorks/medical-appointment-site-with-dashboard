<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Appointment;
use App\Models\User;
use App\Models\Schedule;
use Carbon\Carbon;

class AppointmentController extends Controller
{
    /**
     * عرض المواعيد حسب الدور
     */
    public function index()
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        $user = Auth::user();

        if ($user->role === 'doctor') {
            $appointments = Appointment::where('doctor_id', $user->id)->with('patient')->get();
        } else {
            $appointments = Appointment::where('patient_id', $user->id)->with('doctor')->get();
        }

        return view('appointments.index', compact('appointments'));
    }

    /**
     * عرض نموذج حجز موعد جديد
     */
    public function create()
    {
        $doctors = User::where('role', 'doctor')->get();
        return view('appointments.create', compact('doctors'));
    }

    /**
     * حفظ بيانات الموعد
     */
    public function store(Request $request)
    {
        $request->validate([
            'doctor_id' => 'required|exists:users,id',
            'appointment_date' => 'required|date',
            'appointment_time' => 'required',
        ]);

        $dayName = Carbon::parse($request->appointment_date)->format('l');

        $schedule = Schedule::where('doctor_id', $request->doctor_id)
            ->where('day_of_week', $dayName)
            ->where('start_time', '<=', $request->appointment_time)
            ->where('end_time', '>=', $request->appointment_time)
            ->first();

        if (!$schedule) {
            return back()->withErrors(['appointment_time' => 'This time is not available for this doctor.']);
        }

        $exists = Appointment::where('doctor_id', $request->doctor_id)
            ->where('appointment_date', $request->appointment_date)
            ->where('appointment_time', $request->appointment_time)
            ->where('patient_id', auth()->id())
            ->exists();

        if ($exists) {
            return back()->withErrors(['appointment_time' => 'You already booked this appointment.']);
        }

        Appointment::create([
            'doctor_id' => $request->doctor_id,
            'patient_id' => auth()->id(),
            'appointment_date' => $request->appointment_date,
            'appointment_time' => $request->appointment_time,
            'status' => 'pending',
        ]);

        return redirect()->route('patient.appointments')->with('success', 'Appointment booked successfully!');
    }

    /**
     * تأكيد الموعد (الدكتور فقط)
     */
    public function confirm(Appointment $appointment)
    {
        if (Auth::id() !== $appointment->doctor_id) {
            abort(403);
        }

        $appointment->update(['status' => 'confirmed']);
        return back()->with('success', 'Appointment confirmed.');
    }

    /**
     * إلغاء الموعد (الدكتور فقط)
     */
    public function cancel(Appointment $appointment)
    {
        if (Auth::id() !== $appointment->doctor_id) {
            abort(403);
        }

        $appointment->update(['status' => 'cancelled']);
        return back()->with('success', 'Appointment cancelled.');
    }
}
