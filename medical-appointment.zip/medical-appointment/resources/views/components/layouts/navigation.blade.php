<nav class="bg-white shadow mb-4 p-4 flex justify-between items-center">
    <div>
        <a href="/" class="font-bold text-lg text-blue-700">Medical System</a>
    </div>

    <div class="flex items-center">
        @auth
            <span class="text-sm text-gray-700">
                {{ auth()->user()->name }} 
                <span class="text-xs text-gray-500">({{ ucfirst(auth()->user()->role) }})</span>
            </span>

            {{-- Dashboard Link حسب الدور --}}
            @if(auth()->user()->role === 'doctor')
                <a href="{{ route('doctor.dashboard') }}" class="ml-4 text-blue-600 hover:underline text-sm">Dashboard</a>
            @elseif(auth()->user()->role === 'patient')
                <a href="{{ route('patient.dashboard') }}" class="ml-4 text-blue-600 hover:underline text-sm">Dashboard</a>
            @endif

            {{-- Logout --}}
            <form method="POST" action="{{ route('logout') }}" class="inline ml-4">
                @csrf
                <button class="text-red-500 hover:text-red-700 text-sm">Logout</button>
            </form>
        @else
            <a href="{{ route('login') }}" class="text-sm text-blue-500 hover:underline">Login</a>
            <a href="{{ route('register') }}" class="ml-3 text-sm text-blue-500 hover:underline">Register</a>
        @endauth
    </div>
</nav>
