<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-bold">My Patient Appointments</h2>
    </x-slot>

    <div class="p-4">

        {{-- رسالة نجاح --}}
        @if(session('success'))
            <div class="bg-green-100 text-green-800 p-3 rounded mb-4 shadow">
                {{ session('success') }}
            </div>
        @endif

        @if($appointments->count())
            <table class="w-full table-auto border rounded shadow">
                <thead class="bg-gray-100 text-left">
                    <tr>
                        <th class="p-3 border">Patient</th>
                        <th class="p-3 border">Date</th>
                        <th class="p-3 border">Time</th>
                        <th class="p-3 border">Status</th>
                        <th class="p-3 border">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($appointments as $appointment)
                        <tr class="hover:bg-gray-50">
                            <td class="p-3 border">{{ $appointment->patient->name }}</td>
                            <td class="p-3 border">{{ $appointment->appointment_date }}</td>
                            <td class="p-3 border">{{ $appointment->appointment_time }}</td>
                            <td class="p-3 border">
                                <span class="px-2 py-1 text-sm font-semibold rounded 
                                    {{ $appointment->status == 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                        ($appointment->status == 'confirmed' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800') }}">
                                    {{ ucfirst($appointment->status) }}
                                </span>
                            </td>
                            <td class="p-3 border">
                                @if($appointment->status == 'pending')
                                    <div class="flex space-x-2">
                                        {{-- Confirm --}}
                                        <form method="POST" action="{{ route('doctor.appointments.updateStatus', $appointment->id) }}">
                                            @csrf
                                            <input type="hidden" name="status" value="confirmed">
                                            <button type="submit" class="text-green-600 hover:underline" onclick="return confirm('Are you sure to confirm this appointment?')">
                                                ✅ Confirm
                                            </button>
                                        </form>

                                        {{-- Cancel --}}
                                        <form method="POST" action="{{ route('doctor.appointments.updateStatus', $appointment->id) }}">
                                            @csrf
                                            <input type="hidden" name="status" value="cancelled">
                                            <button type="submit" class="text-red-600 hover:underline"
                                                onclick="return confirm('Are you sure to cancel this appointment?')">
                                                ❌ Cancel
                                            </button>
                                        </form>
                                    </div>
                                @else
                                    <span class="text-gray-400 italic">No actions</span>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @else
            <div class="text-gray-600 text-center mt-8">
                No appointments yet.
            </div>
        @endif

    </div>
</x-app-layout>
