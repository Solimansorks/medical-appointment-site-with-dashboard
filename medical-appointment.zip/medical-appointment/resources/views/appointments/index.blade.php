<x-app-layout>
    <h2 class="text-xl font-bold mb-4">My Appointments</h2>

    {{-- ✅ رسالة نجاح --}}
    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    {{-- ✅ جدول المواعيد --}}
    <table class="w-full table-auto border">
        <thead class="bg-gray-100">
            <tr>
                <th class="p-2 border">#</th>
                @if(auth()->user()->role === 'doctor')
                    <th class="p-2 border">Patient</th>
                @else
                    <th class="p-2 border">Doctor</th>
                @endif
                <th class="p-2 border">Date</th>
                <th class="p-2 border">Time</th>
                <th class="p-2 border">Status</th>
            </tr>
        </thead>
        <tbody>
            @php
                $statusColors = [
                    'pending' => 'bg-yellow-200 text-yellow-800',
                    'confirmed' => 'bg-green-200 text-green-800',
                    'cancelled' => 'bg-red-200 text-red-800',
                ];
            @endphp

            @forelse($appointments as $appointment)
                <tr class="border">
                    <td class="p-2 border">{{ $loop->iteration }}</td>

                    {{-- 👤 عرض اسم الدكتور أو المريض حسب الدور --}}
                    <td class="p-2 border">
                        {{ auth()->user()->role === 'doctor'
                            ? $appointment->patient->name ?? '-' 
                            : $appointment->doctor->name ?? '-' }}
                    </td>

                    <td class="p-2 border">{{ $appointment->appointment_date }}</td>
                    <td class="p-2 border">{{ $appointment->appointment_time }}</td>
                    
                    <td class="p-2 border">
                        <span class="px-2 py-1 rounded {{ $statusColors[$appointment->status] ?? 'bg-gray-200' }}">
                            {{ ucfirst($appointment->status) }}
                        </span>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="text-center p-4 text-gray-600">
                        No appointments found.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</x-app-layout>
