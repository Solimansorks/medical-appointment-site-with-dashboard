<x-app-layout>
    <h2 class="text-xl font-bold mb-4">🧾 Prescription</h2>

    <div class="border p-4 rounded bg-white shadow">
        <p class="whitespace-pre-line text-lg text-gray-800">
            {{ $prescription->content }}
        </p>
    </div>

    <button onclick="window.print()" class="mt-4 bg-gray-800 text-white px-4 py-2 rounded">
        🖨️ Print Prescription
    </button>
</x-app-layout>
